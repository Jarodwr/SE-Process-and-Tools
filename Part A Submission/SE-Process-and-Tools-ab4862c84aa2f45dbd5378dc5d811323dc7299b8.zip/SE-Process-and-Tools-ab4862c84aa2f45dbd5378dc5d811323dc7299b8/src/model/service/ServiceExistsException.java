package model.service;

public class ServiceExistsException extends Exception {
	
}
