package view.gui;

public class RegisterController {

}
