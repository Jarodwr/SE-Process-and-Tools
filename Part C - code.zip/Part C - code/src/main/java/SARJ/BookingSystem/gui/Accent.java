package SARJ.BookingSystem.gui;

public abstract interface Accent {
	
	public void changeColour(String colour);

}
