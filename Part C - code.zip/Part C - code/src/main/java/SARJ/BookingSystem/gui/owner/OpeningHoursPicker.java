package SARJ.BookingSystem.gui.owner;


public class OpeningHoursPicker extends AvailabilityPicker {
	
	
	 
   
}
    
    
