package SARJ.BookingSystem.model.exceptions;

public class ServiceExistsException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
}
